# BetroxyOfficialBot - Railway package

This merged build preserves the existing PostgreSQL affiliate/admin system and updates the public `/start` screen to match the original Betroxy bot layout.

## Railway variables required
- BOT_TOKEN
- DATABASE_URL
- ADMIN_ID

## Deploy
Replace the existing `bot.py` with this package's `bot.py`, keep the existing Railway variables, and redeploy.

## Main menu app
The blue Telegram `Open App` menu button points to:
https://www.betroxy.com

## Important
The public game/account buttons currently point to the corresponding `@BetroxyBot` Telegram links. If any specific deep-link slug differs on the original bot, update the URL constants near the top of `bot.py`.
